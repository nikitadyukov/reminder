//
//  HomeViewController.swift
//  slideBar4.0
//
//  Created by Никита Дюков on 05.09.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import UIKit

protocol HomeViewControllerDelegate: AnyObject {
    func didTapMenuButton()
}


class HomeViewController: UIViewController {

    weak var delegate: HomeViewControllerDelegate?
    
    var portfolioTxt = UILabel()
    
    
    var listImage = #imageLiteral(resourceName: "list-text")
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .black
        navigationController?.navigationBar.barStyle = UIBarStyle.black
        

        
        portfolioTxt.frame = CGRect(x: view.center.x - 150 , y: view.center.y - 300, width: 300, height: 400)
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: listImage,
                                                           style: .done,
                                                           target: self,
                                                           action: #selector(didTapMenuButton))
        navigationItem.leftBarButtonItem?.tintColor = UIColor(white: 1, alpha: 0.0)

        UIView.animate(withDuration: 5.0) {
            self.animatePortfolio()
            self.portfolioTxt.alpha = 1.0
            self.navigationItem.leftBarButtonItem?.tintColor = UIColor(white: 1.0, alpha: 1.0)

        }
//        UIView.animate(withDuration: 3.0) {
//            self.navigationItem.leftBarButtonItem?.tintColor = UIColor(white: 1.0, alpha: 0.0)
//        } completion: { (_) in
//            self.navigationItem.leftBarButtonItem?.tintColor = UIColor(white: 1.0, alpha: 1.0)
//        }

        
        
        
        
        
     
        
}
    @objc func didTapMenuButton() {
        delegate?.didTapMenuButton()
    }

    
    
    
    
    
    
    
    
    
    func animatePortfolio() {
        portfolioTxt.font = portfolioTxt.font.withSize(20)
        portfolioTxt.numberOfLines = 3
        portfolioTxt.adjustsFontForContentSizeCategory = true
        portfolioTxt.textAlignment = .center
        portfolioTxt.lineBreakMode = .byWordWrapping
        portfolioTxt.backgroundColor = .black
        portfolioTxt.alpha = 0.0
        portfolioTxt.text = "Это приложение - портфолио. Нажмите на меню в левом углу экрана..."
        portfolioTxt.textAlignment = .center
        portfolioTxt.textColor = .white
        view.addSubview(portfolioTxt)
    }

}
