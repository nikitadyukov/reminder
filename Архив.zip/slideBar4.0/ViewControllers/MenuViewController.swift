//
//  MenuViewController.swift
//  slideBar4.0
//
//  Created by Никита Дюков on 05.09.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  


    //MARK: - Prop
    
    
    var calcGreen: UIColor = UIColor.init(red: 0.181, green: 0.383, blue: 0.255, alpha: 1.0)
    
    var delegate: MenuViewControllerDelegate?
    
    
    public let tableView: UITableView = {
        let table = UITableView()
        table.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        table.separatorStyle = .none
        table.backgroundColor = nil
        
        return table
    }()
    
    
    
    
    
    enum MenuOptions: String, CaseIterable {
        
        
           case Calculator = "Calculator"
           case Weather = "Weather"
           case Music = "Music"
           case Reminder = "Reminder"

        
        
        var imageName: String {
            switch self {
            
            case .Calculator:
                return "Calculator"
            case .Weather:
                return "Weather"
            case .Music:
                return "music"
            case .Reminder:
                return "notes"
            }
        }
       }
    
    
    
    
    
    //MARK: - funcs
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
         let gradient = CAGradientLayer()
       gradient.colors = [calcGreen.cgColor,UIColor.black]
       
       gradient.startPoint = CGPoint(x: 0, y: 0.5)
        gradient.endPoint = CGPoint(x: 0.7, y: 0.5)
       gradient.frame = self.view.bounds
       self.view.layer.addSublayer(gradient)
        
        
        view.addSubview(tableView)
        view.bringSubviewToFront(tableView)
        
    }
    
    
    func SideGradient(clr: UIColor, nameOfLayer: String) {
        let nameOfLayer = CAGradientLayer()
        nameOfLayer.colors = [clr.cgColor,UIColor.black]
        nameOfLayer.startPoint = CGPoint(x: 0, y: 0.5)
        nameOfLayer.endPoint = CGPoint(x: 0.7, y: 0.5)
        nameOfLayer.frame = self.view.bounds
        self.view.layer.sublayers?.removeAll()
        
        self.view.layer.addSublayer(nameOfLayer)
        self.view.addSubview(tableView)
        self.view.bringSubviewToFront(tableView)

      
      }
    
    
    
    override func viewDidLayoutSubviews() {
         super.viewDidLayoutSubviews()
         tableView.frame = CGRect(x: 0, y: view.safeAreaInsets.top, width: view.bounds.size.width, height: view.bounds.size.height)
        tableView.rowHeight = 60
        
        
     }
    
  func image( _ image:UIImage, withSize newSize:CGSize) -> UIImage {

      UIGraphicsBeginImageContext(newSize)
      image.draw(in: CGRect(x: 0,y: 0,width: newSize.width,height: newSize.height))
      let newImage = UIGraphicsGetImageFromCurrentImageContext()
      UIGraphicsEndImageContext()
      return newImage!.withRenderingMode(.automatic)
  }

    
    
    

    //MARK: - Protocols 0f tableView
   
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return MenuOptions.allCases.count
   }
    
    
   
   
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
//Настройка вида меню
       cell.textLabel?.text = MenuOptions.allCases[indexPath.row].rawValue
       cell.textLabel?.textColor = .white
       cell.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.0)
       cell.selectionStyle = .none
        
    cell.imageView?.image = image(UIImage(named: MenuOptions.allCases[indexPath.row].imageName)!, withSize: CGSize(width: 30, height: 30))
       cell.backgroundColor = nil
       return cell
   }
   

    
    
   func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       tableView.deselectRow(at: indexPath, animated: true)
       let item = MenuOptions.allCases[indexPath.row]
       delegate?.didSelect(menuItem: item)
   }
    
    
    
    
    
    
    

}


protocol MenuViewControllerDelegate: AnyObject {
    func didSelect(menuItem: MenuViewController.MenuOptions)
}
