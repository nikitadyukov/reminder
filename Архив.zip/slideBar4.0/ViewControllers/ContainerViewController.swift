//
//  ViewController.swift
//  slideBar4.0
//
//  Created by Никита Дюков on 05.09.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import UIKit

class ContainerViewController: UIViewController, HomeViewControllerDelegate, MenuViewControllerDelegate {
    
    //MARK: - PROP
    var isOpen = false
    
    
    
    let menuVC = MenuViewController()
    let homeVC = HomeViewController()
    
    
    var navVC: UINavigationController?
    
    lazy var calculatorVC = CalculatorViewController()
    lazy var weatherVC = WeatherView()
    lazy var musicVC = MusicViewController()
    lazy var reminderVC = ReminderViewController()

    var calcOn = true
    var weatherOn = true
    var musicOn = true
    var reminderOn = true
    
    var conditions = [Bool] ()
    
    func addition(chosen: Bool){
        conditions.removeAll()
        conditions.append(chosen)
    }
    
    
    
    func didSelect(menuItem: MenuViewController.MenuOptions) {
        toggleMenu (completion: nil)
            switch menuItem {
                
            case .Calculator:
                self.addVC(VC: self.calculatorVC)
                addition(chosen: calcOn)
                                
            case .Weather:
                self.addVC(VC: self.weatherVC)
               addition(chosen: weatherOn)
                
            case .Music:
                 self.addVC(VC: self.musicVC)
                addition(chosen: musicOn)
                
            case .Reminder:
                self.addVC(VC: self.reminderVC)
                addition(chosen: reminderOn)
            }
        }
    

 
    
    func addVC(VC: UIViewController) {
        let vc = VC
        self.homeVC.addChild(vc)
        self.homeVC.view.addSubview(vc.view)
        vc.view.frame = self.view.frame
        vc.didMove(toParent: self.homeVC)
        

        if vc == calculatorVC {
            calcOn = true
            weatherOn = false
            musicOn = false
            reminderOn = false
            return
        }
        if vc == weatherVC {
            weatherOn = true
            musicOn = false
            reminderOn = false
            calcOn = false
            
            return
        }
        if vc == musicVC{
            musicOn = true
            reminderOn = false
            calcOn = false
            weatherOn = false
            return
        }
        if vc == reminderVC {
            
            reminderOn = true
            calcOn = false
            musicOn = false
            weatherOn = false
            return
        }
        
    }
    
    
   
    
    func didTapMenuButton() {
        
        if conditions.contains(calcOn == true) {
            menuVC.SideGradient(clr: .brown, nameOfLayer: "calcColor")
            conditions.removeAll()
            }
        
            if conditions.contains(weatherOn == true) {
                menuVC.SideGradient(clr: weatherVC.mainColor, nameOfLayer: "weatherColor")
                conditions.removeAll()
            }
            
            if conditions.contains(musicOn == true) {
                menuVC.SideGradient(clr: UIColor.systemPink, nameOfLayer: "musicColor")
                conditions.removeAll()
            }
            

            if conditions.contains(reminderOn == true) {
                menuVC.SideGradient(clr: UIColor.lightGray, nameOfLayer: "reminderColor")
                conditions.removeAll()
            }
        
        toggleMenu(completion: nil)


    }
    
    func toggleMenu(completion: (() -> Void)?) {
        if isOpen == false{
                             self.menuVC.view.alpha = 0.0
                             UIView.animate(withDuration: 0.8,
                                            delay: 0.0,
                                            usingSpringWithDamping: 0.8,
                                            initialSpringVelocity: 0,
                                            options: .transitionFlipFromLeft,
                                            animations: {
                                               self.navVC?.view.frame.origin.x = self.homeVC.view.frame.width - 150})
                                             isOpen = true
            UIView.animate(withDuration: 0.8) {
                self.menuVC.view.alpha = 1.0
            }
                         }

                         else {
            self.menuVC.view.alpha = 1.0

                                 UIView.animate(withDuration: 0.8,
                                                    delay: 0.0,
                                                    usingSpringWithDamping: 0.8,
                                                    initialSpringVelocity: 0,
                                                    options: .curveEaseInOut,
                                                    animations: {
                                                     self.homeVC.view.frame.origin.x = 0
                                                       self.navVC?.view.frame.origin.x = 0
                                                        self.menuVC.view.alpha = 0.0
                                                        UIView.animate(withDuration: 0.8) {
                                                                      self.menuVC.view.alpha = 0.0
                                                                  }
                                 }, completion: { [ weak self ] done in
                                    if done {
                                        self?.isOpen = false
                                        DispatchQueue.main.async
                                            {completion?()}
                                    }})
                           
            }
                                     

    }
    

   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addChildVCs()
    }

    
    
    private func addChildVCs() {
        addChild(menuVC)
        view.addSubview(menuVC.view)
        menuVC.didMove(toParent: self)
        menuVC.delegate = self
        
        homeVC.delegate = self
        let navVC = UINavigationController(rootViewController: homeVC)
        addChild(navVC)
        view.addSubview(navVC.view)
        navVC.didMove(toParent: self)
        self.navVC = navVC
    }
    
    
}


