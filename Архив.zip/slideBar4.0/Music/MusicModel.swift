//
//  MusicModel.swift
//  slideBar4.0
//
//  Created by ПР on 21.09.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import Foundation

protocol MusicModelDelegate: AnyObject {
    
}

 var delegate: MusicModelDelegate?

struct SongView {
    var songName = String()
    var albumName = String()
    
}
