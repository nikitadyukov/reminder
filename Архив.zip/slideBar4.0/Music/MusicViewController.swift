//
//  MusicViewController.swift
//  slideBar4.0
//
//  Created by Никита Дюков on 05.09.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import UIKit
import Foundation

protocol MusicViewControllerDelegate: AnyObject {
    func didTapMenuButton()
}
// MARK: -Vars
    var spotifyColor = UIColor(red: 6.0/255.0, green: 195.0/255.0, blue: 103.0/255.0, alpha: 1.0)
    var listImage = #imageLiteral(resourceName: "list-text")

  



class MusicViewController: UIViewController {

   weak var delegate: MusicViewControllerDelegate?
        let musicM = SongView()
        let musicA = MusAPI()
       
        
        override func viewDidLoad() {
            super.viewDidLoad()

            view.backgroundColor = spotifyColor
            
            
    }
    
    
    //MARK: -Funcs
    
//    
//    func gettingData(city: String, completion: @escaping (Welcome?, Error?)  -> Void) {
//        print("Пошел func gettingTemp")
//              let weatherURL = "http://api.openweathermap.org/data/2.5/weather?q=\(city)&appid=6de6174f0d2585b08274851cfa39e7ae"
//              guard let stingURL = URL(string: weatherURL) else {return}
//              let task = URLSession.shared.dataTask(with: stingURL) { (data, response, error) in
//                DispatchQueue.main.async {
//                  if let error = error {
//                      completion(nil, error)
//                      print("Хуевый URL")
//                      return
//                  }
//                  guard let data = data else {return}
//                  do {
//                    print("\nПолучил данные о городе...")
//                      let weather = try JSONDecoder().decode(Welcome.self, from: data) // дата
//                    DataWeather.sky = weather.weather.first?.main as! String
//                    if DataWeather.sky == "Clear"{
//                        DataWeather.sky = ""
//                    }
//                    if DataWeather.sky == "Mist"{
//                        DataWeather.sky = "fog"
//                    }
//                    print("Инициализировал sky")
//                      completion(weather, nil)
//                    print("\nСохраняю данные в структуре....")
//                    DataWeather.skyDescription = weather.weather.first?.weatherDescription as! String
//                    DataWeather.pressure = weather.main.pressure
//                    DataWeather.humidity = weather.main.humidity
//                    DataWeather.wind = weather.wind.speed
//                    print("\nДанные загружены в структуру")
//                    print("\nПроверка...")
//                    print("\n\(DataWeather.sky)\n\(DataWeather.skyDescription)\n\(DataWeather.pressure)\n\(DataWeather.humidity)\n\(DataWeather.wind)")
//                  } catch let jsonError{
//                      print("Failed to decode", jsonError)
//                      completion(nil, jsonError)
//                  }
//                    
//              }
//          }
//        task.resume()
//        
//    }
    
    
        @objc func didTapMenuButton() {
            delegate?.didTapMenuButton()
        }

    
    
    
}
