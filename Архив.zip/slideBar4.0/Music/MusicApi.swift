//
//  MusicApi.swift
//  slideBar4.0
//
//  Created by ПР on 21.09.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import Foundation

struct MusAPI {
    var songName = String()
    var clientID = "5f75cb6c778a4a06bec6c9db3356b1f3"
    var clientSecret = "3da6e56441424d8cba7f477bfb131503"
}
