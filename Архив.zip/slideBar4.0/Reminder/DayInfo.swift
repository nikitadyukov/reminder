//
//  DayInfo.swift
//  slideBar4.0
//
//  Created by Никита Дюков on 04.12.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import Foundation
import UIKit


class dayInfo: UIViewController {
    
    var dayDescription = UILabel()
    var dayName = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .lightGray
        
        
        
        
        
        
        
        dayName.text = "Пример"
        dayName.textColor = .black
        dayName.font = UIFont(name: "HelveticaNeue-Bold", size: 45)
        dayName.frame = CGRect(x: 20, y: 20, width: view.bounds.width - 20, height: view.bounds.maxY)
//        dayName.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        dayName.sizeToFit()
        
        dayDescription.numberOfLines = 0
        dayDescription.text = "Потому что социализм неизбежен; потому что современный строй прогнил, вопиюще противоречит здравому смыслу и обречен; потому что времена вашей сильной личности прошли. Рабы ее не потерпят. Их слишком много, и волей-неволей они повергнут наземь так называемую сильную личность еще прежде, чем она окажется на коне. Никуда от них не денешься, и придется вам глотать их рабскую мораль. Признаюсь, радости мало. Но все уже началось, и придется ее заглотать."
        dayDescription.textColor = .black
        dayDescription.font = UIFont(name: "HelveticaNeue", size: 25)
        dayDescription.frame = CGRect(x: 20, y: dayName.frame.maxY + 30, width: view.bounds.width - 20, height: view.bounds.height - 20)
        dayDescription.sizeToFit()
        
        
        view.addSubview(dayDescription)
        view.addSubview(dayName)
        
    }
    
}
