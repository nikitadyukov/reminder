//
//  ReminderViewController.swift
//  slideBar4.0
//
//  Created by Никита Дюков on 05.09.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import UIKit
import Foundation


class ReminderViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var descr = dayInfo()
    var editButton = UIButton()
    var myTableView = UITableView()
    var identifier = "My cell"
    var numberOfSections = ["1-ый день", "2-ой день", "3-ий день", "4-ый день", "5-ый день","6-ой день"]
    
    var plusB = UIButton()
    var data = ["первая заметка", "вторая заметка","третья заметка"]
    var numberOfRowsInSection = Int()
        
       
    override func viewDidLoad() {
        numberOfRowsInSection = data.count
        super.viewDidLoad()
        createRow()
        createButton()
    }
    
    func createButton() {
        editButton.frame = CGRect(x: view.bounds.maxX - 100, y: view.bounds.maxY - 100, width: 50, height: 50)
        editButton.backgroundColor = .lightGray
        editButton.setTitle("+", for: .normal)
        editButton.addTarget(self, action: #selector(touchAdd), for: .touchUpInside)
        editButton.titleShadowColor(for: .normal)
        editButton.tintColor = .white
        editButton.setTitleShadowColor(.black, for: .normal)
        editButton.layer.cornerRadius = .pi
        view.bringSubviewToFront(editButton)
        view.addSubview(editButton)
        
    }
    
    @objc func touchAdd(sender: UIButton) {
        myTableView.beginUpdates()

        let testText = UITextField()
        testText.text = "TEыеы"
        data.append(testText.text!)
        numberOfRowsInSection += 1

        let indexPath = IndexPath(row: data.count, section: 0)
        
        myTableView.insertRows(at: [indexPath], with: .automatic)
        myTableView.endUpdates()
        

    }
    
    
    
    
    func createRow() {
        self.myTableView = UITableView(frame: view.bounds, style: .insetGrouped)
        myTableView.backgroundColor = .lightGray
        myTableView.register(UITableViewCell.self, forCellReuseIdentifier: identifier)
        
        self.myTableView.delegate = self
        self.myTableView.dataSource = self
        
        myTableView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        view.addSubview(myTableView)
        
    }
    

    
    
    //MARK: -- UITableViewDataSource
    
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return numberOfSections.count
    }
    
//    func sectionIndexTitles(for tableView: UITableView) -> [String]? {
//        for name in numberOfSections {
//
//        }
//    }
    
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return numberOfSections[section]
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        for _ in 0...numberOfSections.count {
            return numberOfRowsInSection
        }
        return 0
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Выбран \(numberOfSections[indexPath.first!]) и \(data[indexPath.last!])")
    }
    
   
    
//    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
//        return "Footer"
//    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: identifier, for: indexPath)
//        cell.accessoryType = .detailButton
        
        let number = data[indexPath.row]
        cell.textLabel?.text = number

        
        return cell
    }
    
    
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        showDetailViewController(descr, sender: .none)
//        let ounerCell = myTableView.cellForRow(at: indexPath)
//        print(ounerCell?.textLabel?.text ?? "nill")
    }
    
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, shouldSpringLoadRowAt indexPath: IndexPath, with context: UISpringLoadedInteractionContext) -> Bool {
        return true
    }
    
    
    
    //MARK: -- UITableViewDelegate
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
    }
    
    
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
            print("Удаление \(indexPath)")
            
        }
    }
    
    
    
    
    
    }
