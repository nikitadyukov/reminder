//
//  WeatherViewController.swift
//  slideBar4.0
//
//  Created by Никита Дюков on 05.09.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import UIKit
import Foundation


class WeatherView: UIViewController, UITextFieldDelegate{
    
    
    //MARK: - Protocols
    

    

    
    
    
    //MARK: -Vars
    var windSpeedData = UILabel()
    var windSpeedLabel = UIImageView()
    var sunsetData = UILabel()
    var sunsetLabel = UIImageView()
    var sunriseData = UILabel()
    var sunriseLabel = UIImageView()
    
    
    var VC = WeatherViewController()

    
    var celSign = UILabel()
    var openWeather = Welcome.self
    var nameOfCountry = UILabel()
    var mainColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
    static let textF = UITextField()
    let searchButt = UIButton()
    var weatherDescription = UILabel()
    
    
    var ImageURL = String()
    var nameOfCity = UILabel()
    var tempOfCity = UILabel()
    var searchIcon = UIImageView()
    lazy var safeImage = UIImageView()
    
    var textStatus = false
    
    let blurredView = UIVisualEffectView(effect: UIBlurEffect(style: .light))
    
    
    
    
    let dispQueue = DispatchQueue(label: "DFFFFf")
    let dispGroup = DispatchGroup()
    
    
    //    MARK: - Funcs
    
    
        override func viewDidLoad() {
            super.viewDidLoad()
            safeImage.image = UIImage.actions
            createTextField()
            navigationController?.navigationBar.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.0)
            WeatherView.textF.delegate = self
            view.backgroundColor = .black
            
 
            
            
    }
    

    func createBackground(priority: DispatchQoS, city: String, completion: @escaping (WelcomeImage?, Error?) -> Void) {
        print("Пошла func createBackground")
        let imageURL = "https://pixabay.com/api/?key=23370161-68858c4dc7a8da8189d451c8b&q=city_\(WeatherView.textF.text ?? "city")&image_type=video&pretty=true&orientation=vertical"
        print("Создан URL: \(imageURL)")
          guard let stingURL = URL(string: imageURL) else {return}
          let task = URLSession.shared.dataTask(with: stingURL) { (data, response, error) in
            DispatchQueue.main.async {
              if let error = error {
                  completion(nil, error)
                  print("Хуевый URL")
                  return
              }
              guard let data = data else {return}
              do {
                  let image = try JSONDecoder().decode(WelcomeImage.self, from: data) // дата
                  completion(image, nil)
              } catch let jsonError{
                  print("Failed to decode", jsonError)
                  completion(nil, jsonError)
              }
                
          }
      }
        print("End func createBackground")
        task.resume()
    }

    
   func createLabelCity(text: String, country: String) {
         nameOfCity.frame = CGRect(x: view.center.x - 135, y: view.center.y - 190, width: 270.0, height: 20.0)
         nameOfCity.text = "\(WeatherModel.DataWeather.region)"
         nameOfCity.textColor = .white
         nameOfCity.textAlignment = .center
         nameOfCity.font.withSize(70)
         nameOfCity.alpha = 0.0

        nameOfCountry.frame = CGRect(x: view.center.x - 135, y: view.center.y - 175, width: 270.0, height: 30.0)
        nameOfCountry.text = "\(WeatherModel.DataWeather.country)"
        nameOfCountry.textColor = .white
        nameOfCountry.textAlignment = .center
        nameOfCountry.font.withSize(70)
        nameOfCountry.alpha = 0.0
    
         self.view.addSubview(self.nameOfCountry)
         self.view.addSubview(self.nameOfCity)
         
         UIView.animate(withDuration: 2.5) {
            self.nameOfCountry.alpha = 1.0
            UIView.animate(withDuration: 5.0) {
                self.nameOfCity.alpha = 1.0
            }
         }
     }
    
    func tempOfLabel(temp: Int) {
        tempOfCity.frame = CGRect(x: 0, y: view.center.y - 340.0, width: view.frame.width, height: 170)
        tempOfCity.font = UIFont.systemFont(ofSize: 140)
        tempOfCity.text = "\(Int(temp))°c"
        tempOfCity.textColor = .white
        tempOfCity.textAlignment = .center
        tempOfCity.alpha = 0.0
        self.view.addSubview(self.tempOfCity)
        UIView.animate(withDuration: 1.5) {
            self.tempOfCity.alpha = 1.0
            self.celSign.alpha = 1.0
            UIView.animate(withDuration: 6.5) {
                self.tempOfCity.shadowColor = .black
                self.tempOfCity.shadowOffset = CGSize(width: 1.5, height: 1.5)
            }
        }
    }
    
    func createTextField() {
        searchIcon.frame = CGRect(x: view.center.x - 15 , y: view.center.y - 15, width: 30, height: 30)
        searchIcon.image = #imageLiteral(resourceName: "search")
        searchIcon.alpha = 1.0
        view.addSubview(searchIcon)
        
        WeatherView.textF.frame = CGRect(x: view.center.x - (( view.bounds.width - 100) / 2) , y: view.center.y - 35, width: view.bounds.width - 100, height: 70)
        WeatherView.textF.borderStyle = .roundedRect
        WeatherView.textF.placeholder = "Введите название города"
        WeatherView.textF.layer.cornerRadius = 20
        WeatherView.textF.textAlignment = .center
        WeatherView.textF.textColor = .black
        WeatherView.textF.keyboardAppearance = .dark
        WeatherView.textF.clearButtonMode = .whileEditing
        self.view.center = WeatherView.textF.center
        view.addSubview(WeatherView.textF)
    }
    
    func gettingDesciption() {
        print("\nStart gettingDescription")
        weatherDescription.frame = CGRect(x: 0, y: self.view.center.y - 150.0, width: view.frame.width, height: 100)
        weatherDescription.font = UIFont.italicSystemFont(ofSize: 20)
        weatherDescription.text = "\(WeatherModel.DataWeather.skyDescription)"
        weatherDescription.textColor = .white
        weatherDescription.textAlignment = .center
        weatherDescription.alpha = 0.0
        self.view.addSubview(self.weatherDescription)
        UIView.animate(withDuration: 6.5) {
            self.weatherDescription.alpha = 1.0
        }
        print("\nEnd gettingDescription")
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        UIView.animate(withDuration: 0.3) {
            textField.frame =  CGRect(x: self.view.center.x - (( self.view.bounds.width - 100) / 2) , y: self.view.center.y - 35, width: self.view.bounds.width - 100, height: 70)
            textField.alpha = 1.0
            self.searchIcon.frame = CGRect(x: self.view.center.x - 15 , y: self.view.center.y - 15, width: 30, height: 30)
            self.searchButt.alpha = 0.0
        }
        self.view.bringSubviewToFront(textField)
        return true
    }
 
        
    
    
    func detailWeather() {
        print("start func detailWeather")
        sunriseLabel.image = #imageLiteral(resourceName: "sunrise")
        sunriseLabel.frame = CGRect(x: view.center.x - view.frame.width/2.5, y: view.center.y - 80, width: 50, height: 50)
        sunriseLabel.alpha = 0.0
        
        sunriseData.frame = CGRect(x: view.center.x - view.frame.width/2.5 - sunriseLabel.frame.width/6, y: view.center.y - 80 + sunriseLabel.frame.height, width: 100, height: 50)
        sunriseData.textColor = .white
        sunriseData.alpha = 0.0

        
        windSpeedLabel.image = #imageLiteral(resourceName: "wind-signal")
        windSpeedLabel.frame = CGRect(x: view.center.x - sunriseLabel.frame.width/2, y: view.center.y - 80, width: 50, height: 50)
        windSpeedLabel.alpha = 0.0
        
        windSpeedData.frame = CGRect(x: view.center.x - sunriseLabel.frame.width/2, y: view.center.y - 80 + windSpeedLabel.frame.height, width: 100, height: 50)
        windSpeedData.textColor = .white
        windSpeedData.alpha = 0.0
        
        
        sunsetLabel.image = #imageLiteral(resourceName: "sunset")
        sunsetLabel.frame = CGRect(x: view.center.x + view.frame.width/2.5 - sunriseLabel.frame.width, y: view.center.y - 80, width: 50, height: 50)
        sunsetLabel.alpha = 0.0

        sunsetData.frame = CGRect(x: view.center.x + view.frame.width/2.5 - sunriseLabel.frame.width - sunriseLabel.frame.width/6 , y: view.center.y - 80 + sunsetLabel.frame.height, width: 100, height: 50)
        sunsetData.textColor = .white
        sunsetData.alpha = 0.0
        
        view.addSubview(sunsetData)
        view.addSubview(sunsetLabel)
        
        view.addSubview(windSpeedData)
        view.addSubview(windSpeedLabel)
        
        view.addSubview(sunriseData)
        view.addSubview(sunriseLabel)
        print("end func detailWeather")

    }
    
    
    func turnDownSearchIcon(textField: UITextField) {
        UIView.animate(withDuration: 0.3) {
            textField.backgroundColor?.withAlphaComponent(1.0)
            textField.frame = CGRect(x: self.view.center.x - 15 , y: self.view.center.y + 300, width: 45, height: 45)
            textField.alpha = 0.015
            self.searchIcon.frame = CGRect(x: self.view.center.x - 15, y: self.view.center.y + 300, width: 30, height: 30)
            self.searchButt.alpha = 1.0
            self.view.bringSubviewToFront(textField)
        }
    }
    
    func loadData() {
        
        
        dispQueue.async(group: dispGroup) {
           
        }
        
        dispQueue.async(group: dispGroup) {
           
        }
    }
    
    
    
    
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        VC.gettingData(queue: .main, priority: .userInteractive, city: WeatherView.textF.text!){ (weather, error) in
                self.createLabelCity(text: weather?.location.name ?? "Некорректный город", country: weather?.location.region ?? "Некорректный город")
                self.gettingDesciption()
                if let  currentTemp = weather?.current.tempC {
                    self.tempOfLabel(temp: Int(currentTemp))
                }
        }
        
        
        
        
        createBackground(priority: .background, city: WeatherView.textF.text!) { (image, error) in
            print("\nПошла createBackground")
            self.ImageURL = image?.hits.first?.largeImageURL ?? "Хуевый город"
            let url = URL(string: self.ImageURL)
            let data = try? Data(contentsOf: url ?? WeatherModel.DataWeather.imageWithoutSky!)
            let imageView = UIImage(data: data!)
            imageView?.imageRendererFormat.preferredRange = .unspecified
            if self.view.backgroundColor != .black {
                UIView.animate(withDuration: 3.0) {
                    self.view.backgroundColor?.withAlphaComponent(0.0)
                    self.view.backgroundColor = UIColor.black
                } completion: { (Bool) in
                    UIView.animate(withDuration: 1.0) {
                                self.view.backgroundColor = UIColor(patternImage: ((imageView ?? self.safeImage.image)!))
                            }
                }
            }
            if self.view.backgroundColor == UIColor.black {
                UIView.animate(withDuration: 3.0) {
                    self.view.backgroundColor = UIColor(patternImage: ((imageView ?? self.safeImage.image)!))
                }
            }
            print("End createBackground\n")

        }
    
        delay(bySeconds: 1.0) {
            UIView.animate(withDuration: 1.0) { [self] in
                
                sunsetData.text = "\(WeatherModel.DataWeather.sunset)"
                sunsetLabel.alpha = 1.0
                
                sunriseData.text = "\(WeatherModel.DataWeather.sunrise)"
                sunriseLabel.alpha = 1.0
                
                windSpeedData.text = "\(WeatherModel.DataWeather.windSpeed) km/h"
                windSpeedLabel.alpha = 1.0
            }
        }
        delay(bySeconds: 2.0) {
            UIView.animate(withDuration: 1.0) {
                self.sunriseData.alpha = 1.0
            }
            delay(bySeconds: 0.5) {
                UIView.animate(withDuration: 1.0) {
                    self.windSpeedData.alpha = 1.0
                }
                delay(bySeconds: 0.5) {
                    UIView.animate(withDuration: 1.0) {
                        self.sunsetData.alpha = 1.0
                    }
                }
            }
           
        }
        
        
        
        
        
        
        
        
        
        
        loadData()
        
        
        self.turnDownSearchIcon(textField: textField)
        self.view.endEditing(true)
        WeatherView.textF.text = ""
        //Рассветы
        self.detailWeather()
        
        
        return true
    }


}
    
    
    
    
    
    
    


public func delay(bySeconds seconds: Double, dispatchLevel: DispatchLevel = .main, closure: @escaping () -> Void) {
    let dispatchTime = DispatchTime.now() + seconds
    dispatchLevel.dispatchQueue.asyncAfter(deadline: dispatchTime, execute: closure)
}

public enum DispatchLevel {
    case main, userInteractive, userInitiated, utility, background
    var dispatchQueue: DispatchQueue {
        switch self {
        case .main:                 return DispatchQueue.main
        case .userInteractive:      return DispatchQueue.global(qos: .userInteractive)
        case .userInitiated:        return DispatchQueue.global(qos: .userInitiated)
        case .utility:              return DispatchQueue.global(qos: .utility)
        case .background:           return DispatchQueue.global(qos: .background)
        }
    }
}

