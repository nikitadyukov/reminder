// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? newJSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct Welcome: Codable {
    let location: Location
    let current: Current
    let forecast: Forecast
}

// MARK: - Current
struct Current: Codable {
    let lastUpdatedEpoch: Double
    let lastUpdated: String
    let tempC: Double
    let tempF: Double
    let isDay: Double
    let condition: Condition
    let windMph: Double
    let windKph, windDegree: Double
    let windDir: String
    let pressureMB: Double
    let pressureIn: Double
    let precipMm, precipIn, humidity, cloud: Double
    let feelslikeC: Double
    let feelslikeF: Double
    let visKM, visMiles, uv: Double
    let gustMph, gustKph: Double

    enum CodingKeys: String, CodingKey {
        case lastUpdatedEpoch = "last_updated_epoch"
        case lastUpdated = "last_updated"
        case tempC = "temp_c"
        case tempF = "temp_f"
        case isDay = "is_day"
        case condition
        case windMph = "wind_mph"
        case windKph = "wind_kph"
        case windDegree = "wind_degree"
        case windDir = "wind_dir"
        case pressureMB = "pressure_mb"
        case pressureIn = "pressure_in"
        case precipMm = "precip_mm"
        case precipIn = "precip_in"
        case humidity, cloud
        case feelslikeC = "feelslike_c"
        case feelslikeF = "feelslike_f"
        case visKM = "vis_km"
        case visMiles = "vis_miles"
        case uv
        case gustMph = "gust_mph"
        case gustKph = "gust_kph"
    }
}

// MARK: - Condition
struct Condition: Codable {
    let text: Text
    let icon: Icon
    let code: Int
}

enum Icon: String, Codable {
    case cdnWeatherapiCOMWeather64X64Day113PNG = "//cdn.weatherapi.com/weather/64x64/day/113.png"
    case cdnWeatherapiCOMWeather64X64Day116PNG = "//cdn.weatherapi.com/weather/64x64/day/116.png"
    case cdnWeatherapiCOMWeather64X64Day119PNG = "//cdn.weatherapi.com/weather/64x64/day/119.png"
    case cdnWeatherapiCOMWeather64X64Night119PNG = "//cdn.weatherapi.com/weather/64x64/night/119.png"
    case cdnWeatherapiCOMWeather64X64Day122PNG = "//cdn.weatherapi.com/weather/64x64/day/122.png"
    case cdnWeatherapiCOMWeather64X64Day176PNG = "//cdn.weatherapi.com/weather/64x64/day/176.png"
    case cdnWeatherapiCOMWeather64X64Night113PNG = "//cdn.weatherapi.com/weather/64x64/night/113.png"
    case cdnWeatherapiCOMWeather64X64Night116PNG = "//cdn.weatherapi.com/weather/64x64/night/116.png"
    case cdnWeatherapiCOMWeather64X64Night122PNG = "//cdn.weatherapi.com/weather/64x64/night/122.png"
    case cdnWeatherapiCOMWeather64X64Night176PNG = "//cdn.weatherapi.com/weather/64x64/night/176.png"
    case cdnWeatherapiCOMWeather64X64Day353PNG = "//cdn.weatherapi.com/weather/64x64/day/353.png"
    case cdnWeatherapiCOMWeather64X64Night353PNG = "//cdn.weatherapi.com/weather/64x64/night/353.png"
    case cdnWeatherapiCOMWeather64X64Night296PNG = "//cdn.weatherapi.com/weather/64x64/night/296.png"
    case cdnWeatherapiCOMWeather64X64Day296PNG = "//cdn.weatherapi.com/weather/64x64/day/296.png"
    case cdnWeatherapiCOMWeather64X64Day302PNG =
    "//cdn.weatherapi.com/weather/64x64/day/302.png"
    case cdnWeatherapiCOMWeather64X64Day266PNG =
    "//cdn.weatherapi.com/weather/64x64/day/266.png"
    case cdnWeatherapiCOMWeather64X64Day308PNG =
    "//cdn.weatherapi.com/weather/64x64/day/308.png"
    case cdnWeatherapiCOMWeather64X64Night266PNG =
    "//cdn.weatherapi.com/weather/64x64/night/266.png"
    case cdnWeatherapiCOMWeather64X64Day263PNG =
    "//cdn.weatherapi.com/weather/64x64/day/263.png"
    case cdnWeatherapiCOMWeather64X64Night302PNG =
    "//cdn.weatherapi.com/weather/64x64/night/302.png"
    case cdnWeatherapiCOMWeather64X64Day293PNG =
    "//cdn.weatherapi.com/weather/64x64/day/293.png"
    case cdnWeatherapiCOMWeather64X64Night248PNG =
    "//cdn.weatherapi.com/weather/64x64/night/248.png"
    case cdnWeatherapiCOMWeather64X64Night143PNG =
    "//cdn.weatherapi.com/weather/64x64/night/143.png"
    case cdnWeatherapiCOMWeather64X64Day143PNG =
    "//cdn.weatherapi.com/weather/64x64/day/143.png"
    case cdnWeatherapiCOMWeather64X64Night263PNG =
    "//cdn.weatherapi.com/weather/64x64/night/263.png"
    case cdnWeatherapiCOMWeather64X64Day371PNG =
    "//cdn.weatherapi.com/weather/64x64/day/371.png"
    case cdnWeatherapiCOMWeather64X64Day323PNG =
    "//cdn.weatherapi.com/weather/64x64/day/323.png"
    case cdnWeatherapiCOMWeather64X64Day326PNG =
    "//cdn.weatherapi.com/weather/64x64/day/326.png"
    case cdnWeatherapiCOMWeather64X64Day332PNG =
    "//cdn.weatherapi.com/weather/64x64/day/332.png"
    case cdnWeatherapiCOMWeather64X64Day338PNG =
    "//cdn.weatherapi.com/weather/64x64/day/338.png"
    case cdnWeatherapiCOMWeather64X64Night308PNG =
    "//cdn.weatherapi.com/weather/64x64/night/308.png"
    case cdnWeatherapiCOMWeather64X64Day311PNG =
    "//cdn.weatherapi.com/weather/64x64/day/311.png"
    case cdnWeatherapiCOMWeather64X64Day386PNG =
    "//cdn.weatherapi.com/weather/64x64/day/386.png"
    case cdnWeatherapiCOMWeather64X64Night293PNG =
    "//cdn.weatherapi.com/weather/64x64/night/293.png"
    case cdnWeatherapiCOMWeather64X64Day299PNG =
    "//cdn.weatherapi.com/weather/64x64/day/299.png"
    case cdnWeatherapiCOMWeather64X64Night200PNG =
    "//cdn.weatherapi.com/weather/64x64/night/200.png"
    case cdnWeatherapiCOMWeather64X64Night299PNG =
    "//cdn.weatherapi.com/weather/64x64/night/299.png"
    case cdnWeatherapiCOMWeather64X64Night260PNG =
    "//cdn.weatherapi.com/weather/64x64/night/260.png"
    case cdnWeatherapiCOMWeather64X64Day200PNG =
    "//cdn.weatherapi.com/weather/64x64/day/200.png"
    case cdnWeatherapiCOMWeather64X64Day356PNG =
    "//cdn.weatherapi.com/weather/64x64/day/356.png"
    case cdnWeatherapiCOMWeather64X64Night356PNG =
    "//cdn.weatherapi.com/weather/64x64/night/356.png"
    case cdnWeatherapiCOMWeather64X64Day248PNG = 
    "//cdn.weatherapi.com/weather/64x64/day/248.png"
    case cdnWeatherapiCOMWeather64X64Night389PNG =
    "//cdn.weatherapi.com/weather/64x64/night/389.png"
    case cdnWeatherapiCOMWeather64X64Night386PNG =
    "//cdn.weatherapi.com/weather/64x64/night/386.png"
    case cdnWeatherapiCOMWeather64X64Night305PNG =
    "//cdn.weatherapi.com/weather/64x64/night/305.png"
    case cdnWeatherapiCOMWeather64X64Day359PNG =
    "//cdn.weatherapi.com/weather/64x64/day/359.png"
    case cdnWeatherapiCOMWeather64X64Night359PNG = 
    "//cdn.weatherapi.com/weather/64x64/night/359.png"
    case cdnWeatherapiCOMWeather64X64Night317PNG = 
    "//cdn.weatherapi.com/weather/64x64/night/317.png"
    case cdnWeatherapiCOMWeather64X64Day260PNG = 
    "//cdn.weatherapi.com/weather/64x64/day/260.png"
    case cdnWeatherapiCOMWeather64X64Day182PNG =
    "//cdn.weatherapi.com/weather/64x64/day/182.png"
    case cdnWeatherapiCOMWeather64X64Day389PNG =
    "//cdn.weatherapi.com/weather/64x64/day/389.png"
    case cdnWeatherapiCOMWeather64X64Night338PNG =
    "//cdn.weatherapi.com/weather/64x64/night/338.png"
    case cdnWeatherapiCOMWeather64X64Day329PNG =
    "//cdn.weatherapi.com/weather/64x64/day/329.png"
    case cdnWeatherapiCOMWeather64X64Night326PNG =
    "//cdn.weatherapi.com/weather/64x64/night/326.png"
}

enum Text: String, Codable {
    case clear = "Clear"
    case cloudy = "Cloudy"
    case overcast = "Overcast"
    case partlyCloudy = "Partly cloudy"
    case patchyRainPossible = "Patchy rain possible"
    case sunny = "Sunny"
    case lightRainShower = "Light rain shower"
    case lightRain = "Light rain"
    case moderateRain = "Moderate rain"
    case lightDrizzle = "Light drizzle"
    case PatchyLightDrizzle = "Patchy light drizzle"
    case HeavyRain = "Heavy rain"
    case PatchyLightRain = "Patchy light rain"
    case fog = "Fog"
    case mist = "Mist"
    case  heavySnowShowers = "Moderate or heavy snow showers"
    case PatchyLightSnow = "Patchy light snow"
    case lightSnow = "Light snow"
    case moderateSnow = "Moderate snow"
    case heavySnow = "Heavy snow"
    case LightFreezingRain = "Light freezing rain"
    case PatchyLightRainWithThunder = "Patchy light rain with thunder"
    case ModerateRainAtTimes = "Moderate rain at times"
    case ThunderyOutbreaksPossible = "Thundery outbreaks possible"
    case FreezingFog = "Freezing fog"
    case ModerateOrHeavyRainShower = "Moderate or heavy rain shower"
    case lightSleet = "Light sleet"
    case moderateOrHeavyRainWithThunder = "Moderate or heavy rain with thunder"
    case heavyRainAtTimes = "Heavy rain at times"
    case TorrentialRainShower = "Torrential rain shower"
    case PatchySleetPossible = "Patchy sleet possible"
    case PatchyModerateSnow = "Patchy moderate snow"
    case LightSnowShowers = "Light snow showers"
}

// MARK: - Forecast
struct Forecast: Codable {
    let forecastday: [Forecastday]
}

// MARK: - Forecastday
struct Forecastday: Codable {
    let date: String
    let dateEpoch: Double
    let day: Day
    let astro: Astro
    let hour: [Hour]

    enum CodingKeys: String, CodingKey {
        case date
        case dateEpoch = "date_epoch"
        case day, astro, hour
    }
}

// MARK: - Astro
struct Astro: Codable {
    let sunrise, sunset, moonrise, moonset: String
    let moonPhase, moonIllumination: String

    enum CodingKeys: String, CodingKey {
        case sunrise, sunset, moonrise, moonset
        case moonPhase = "moon_phase"
        case moonIllumination = "moon_illumination"
    }
}

// MARK: - Day
struct Day: Codable {
    let maxtempC, maxtempF, mintempC, mintempF: Double
    let avgtempC, avgtempF, maxwindMph, maxwindKph: Double
    let totalprecipMm: Double
    let totalprecipIn, avgvisKM, avgvisMiles, avghumidity: Double
    let dailyWillItRain, dailyChanceOfRain, dailyWillItSnow, dailyChanceOfSnow: Double
    let condition: Condition
    let uv: Int

    enum CodingKeys: String, CodingKey {
        case maxtempC = "maxtemp_c"
        case maxtempF = "maxtemp_f"
        case mintempC = "mintemp_c"
        case mintempF = "mintemp_f"
        case avgtempC = "avgtemp_c"
        case avgtempF = "avgtemp_f"
        case maxwindMph = "maxwind_mph"
        case maxwindKph = "maxwind_kph"
        case totalprecipMm = "totalprecip_mm"
        case totalprecipIn = "totalprecip_in"
        case avgvisKM = "avgvis_km"
        case avgvisMiles = "avgvis_miles"
        case avghumidity
        case dailyWillItRain = "daily_will_it_rain"
        case dailyChanceOfRain = "daily_chance_of_rain"
        case dailyWillItSnow = "daily_will_it_snow"
        case dailyChanceOfSnow = "daily_chance_of_snow"
        case condition, uv
    }
}

// MARK: - Hour
struct Hour: Codable {
    let timeEpoch: Double
    let time: String
    let tempC, tempF: Double
    let isDay: Int
    let condition: Condition
    let windMph, windKph: Double
    let windDegree: Double
    let windDir: String
    let pressureMB: Double
    let pressureIn, precipMm: Double
    let precipIn, humidity, cloud: Double
    let feelslikeC, feelslikeF, windchillC, windchillF: Double
    let heatindexC, heatindexF, dewpointC, dewpointF: Double
    let willItRain, chanceOfRain, willItSnow, chanceOfSnow: Double
    let visKM, visMiles: Double
    let gustMph, gustKph: Double
    let uv: Double

    enum CodingKeys: String, CodingKey {
        case timeEpoch = "time_epoch"
        case time
        case tempC = "temp_c"
        case tempF = "temp_f"
        case isDay = "is_day"
        case condition
        case windMph = "wind_mph"
        case windKph = "wind_kph"
        case windDegree = "wind_degree"
        case windDir = "wind_dir"
        case pressureMB = "pressure_mb"
        case pressureIn = "pressure_in"
        case precipMm = "precip_mm"
        case precipIn = "precip_in"
        case humidity, cloud
        case feelslikeC = "feelslike_c"
        case feelslikeF = "feelslike_f"
        case windchillC = "windchill_c"
        case windchillF = "windchill_f"
        case heatindexC = "heatindex_c"
        case heatindexF = "heatindex_f"
        case dewpointC = "dewpoint_c"
        case dewpointF = "dewpoint_f"
        case willItRain = "will_it_rain"
        case chanceOfRain = "chance_of_rain"
        case willItSnow = "will_it_snow"
        case chanceOfSnow = "chance_of_snow"
        case visKM = "vis_km"
        case visMiles = "vis_miles"
        case gustMph = "gust_mph"
        case gustKph = "gust_kph"
        case uv
    }
}

// MARK: - Location
struct Location: Codable {
    let name, region, country: String
    let lat, lon: Double
    let tzID: String
    let localtimeEpoch: Double
    let localtime: String

    enum CodingKeys: String, CodingKey {
        case name, region, country, lat, lon
        case tzID = "tz_id"
        case localtimeEpoch = "localtime_epoch"
        case localtime
    }
}

























//  MARK: - Image request



// MARK: - Welcome
struct WelcomeImage: Codable {
    let total, totalHits: Int
    let hits: [Hit]
}

// MARK: - Hit
struct Hit: Codable {
    let id: Int
    let pageURL: String
    let type: TypeEnum
    let tags: String
    let previewURL: String
    let previewWidth, previewHeight: Int
    let webformatURL: String
    let webformatWidth, webformatHeight: Int
    let largeImageURL: String
    let imageWidth, imageHeight, imageSize, views: Int
    let downloads, collections, likes, comments: Int
    let userID: Int
    let user: String
    let userImageURL: String

    enum CodingKeys: String, CodingKey {
        case id, pageURL, type, tags, previewURL, previewWidth, previewHeight, webformatURL, webformatWidth, webformatHeight, largeImageURL, imageWidth, imageHeight, imageSize, views, downloads, collections, likes, comments
        case userID = "user_id"
        case user, userImageURL
    }
}

enum TypeEnum: String, Codable {
    case photo = "photo"
    case illustration = "illustration"
    case vector = "vector/svg"
    case vectorAI = "vector/ai"

}

