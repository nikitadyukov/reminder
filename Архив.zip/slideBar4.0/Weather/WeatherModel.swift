//
//  WeatherModel.swift
//  slideBar4.0
//
//  Created by ПР on 22.09.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import Foundation
import UIKit

class WeatherModel {
    
    //MARK: -Vars
    
    public struct DataWeather {
         static var country = String()
         static var region = String()
         static var sky = String()
         static var skyDescription = String()
         static var pressure = Int()
         static var time = Int()
         static var wind = Double()
         static var imageWithoutSky = URL(string: "https://pixabay.com/api/?key=23370161-68858c4dc7a8da8189d451c8b&q=city&image_type=video&pretty=true")
         static var currentDayTemp = Double()
         static var secondDay = Int()
         static var fourthDay = Int()
         static var fifthDay = Int()
         static var sixthDay = Int()
         static var seventhDay = Int()
         static var sunrise = String()
         static var sunset = String()
         static var windSpeed = Double()
     }
    
    //MARK: - FUNC

    
    func downloadWeather() {
        
    }

    
    
    public func downloadBackground(city: String, completion: @escaping (WelcomeImage?, Error?) -> Void) {
        print("Пошла func downloadBackground")
        let imageURL = "https://pixabay.com/api/?key=23370161-68858c4dc7a8da8189d451c8b&q=city_\(WeatherView.textF.text ?? "city")&image_type=video&pretty=true&orientation=vertical"
        print("\nСоздан URL: \(imageURL)")
          guard let stingURL = URL(string: imageURL) else {return}
          let task = URLSession.shared.dataTask(with: stingURL) { (data, response, error) in
            DispatchQueue.main.async {
              if let error = error {
                  completion(nil, error)
                  print("Хуевый URL")
                  return
              }
              guard let data = data else {return}
              do {
                  let image = try JSONDecoder().decode(WelcomeImage.self, from: data) // дата
                  completion(image, nil)
              } catch let jsonError{
                  print("Failed to decode", jsonError)
                  completion(nil, jsonError)
              }
          }
      }
        print("End func downloadBackground")
        task.resume()
    }
}
