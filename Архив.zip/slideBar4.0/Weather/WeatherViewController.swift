//
//  WeatherViewController.swift
//  slideBar4.0
//
//  Created by Никита Дюков on 05.09.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import UIKit
import Foundation



class WeatherView: UIViewController, UITextFieldDelegate, UICollectionViewDataSource, UICollectionViewDelegate {
    
    
    //MARK: - Protocols
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collection?.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        cell?.layer.cornerRadius = 20
        cell?.backgroundColor = .black
        
        return cell!
    }
    

    
    
    
    //MARK: -Vars
    var windSpeedData = UILabel()
    var windSpeedLabel = UIImageView()
    var sunsetData = UILabel()
    var sunsetLabel = UIImageView()
    var sunriseData = UILabel()
    var sunriseLabel = UIImageView()
    
    
    var view = WeatherViewController()
    
    var celSign = UILabel()
    var openWeather = Welcome.self
    var nameOfCountry = UILabel()
    var mainColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
    let textF = UITextField()
    let searchButt = UIButton()
    var weatherDescription = UILabel()
    
    let weatherV = WeatherViewController()
    let weatherM = WeatherModel()
    
//    var sunriseData = [sun]()
    
    var collection: UICollectionView?
    
    var ImageURL = String()
    var nameOfCity = UILabel()
    var tempOfCity = UILabel()
    var searchIcon = UIImageView()
    lazy var safeImage = UIImageView()
    
    struct sun {
        var sunRiseImage: String
        var sunSetImage: String
        var windImage: String
        
        var dataRise: String
        var dataSet: String
        var dataWind: Double
        
        init(sunRiseImage: String, sunSetImage: String, windImage: String, dataRise: String, dataSet: String, dataWind: Double ) {
            
            self.sunSetImage = sunSetImage
            self.sunRiseImage = sunRiseImage
            self.windImage = windImage
            self.dataRise = dataRise
            self.dataSet = dataSet
            self.dataWind = dataWind
            
        }
        
    }
    
    
   public struct DataWeather {
        static var country = String()
        static var region = String()
        static var sky = String()
        static var skyDescription = String()
        static var pressure = Int()
        static var time = Int()
        static var wind = Double()
        static var imageWithoutSky = URL(string: "https://pixabay.com/api/?key=23370161-68858c4dc7a8da8189d451c8b&q=city&image_type=video&pretty=true")
        static var currentDayTemp = Double()
        static var secondDay = Int()
        static var fourthDay = Int()
        static var fifthDay = Int()
        static var sixthDay = Int()
        static var seventhDay = Int()
        static var sunrise = String()
        static var sunset = String()
        static var windSpeed = Double()
    }
    
    
    //    MARK: - Funcs
    
    
        override func viewDidLoad() {
            super.viewDidLoad()
            safeImage.image = UIImage.actions
            view.backgroundColor = .black
            createTextField()
            navigationController?.navigationBar.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.0)
            textF.delegate = self
            
            
            
            
    }
    

    
    
    

    func gettingData(city: String, completion: @escaping (Welcome?, Error?)  -> Void) {
        print("Пошел func gettingTemp")
              let weatherURL = "http://api.weatherapi.com/v1/forecast.json?key=cead0fe85cfc4f5686d163725211909&q=\(city)&days=3&aqi=no&alerts=no"

              guard let stingURL = URL(string: weatherURL) else {return}
              let task = URLSession.shared.dataTask(with: stingURL) { (data, response, error) in
                DispatchQueue.main.async {
                  if let error = error {
                      completion(nil, error)
                      print("Хуевый URL")
                      return
                  }
                  guard let data = data else {return}
                  do {
                    print("\nПолучил данные о городе...")
                      let weather = try JSONDecoder().decode(Welcome.self, from: data) // дата
                    
                    
                    
                    DataWeather.sky = weather.current.condition.text.rawValue
                    print("Sky: \(DataWeather.sky)")
                    DataWeather.region = weather.location.region
                    print("Region: \(DataWeather.region)")
                    DataWeather.country = weather.location.country
                    print("Country: \(DataWeather.country)")
                    DataWeather.currentDayTemp = weather.current.tempC
                    print("Current temp:\(DataWeather.currentDayTemp)")
                    DataWeather.skyDescription = weather.current.condition.text.rawValue
                    print("Описание погоды: \(weather.current.condition.text.rawValue)")
                    DataWeather.wind = weather.current.windKph
                    print("Скорость ветра: \(DataWeather.wind)")
                      completion(weather, nil)
                    DataWeather.sunrise = weather.forecast.forecastday.first?.astro.sunrise ?? ""
                    print("Время рассвета: \(DataWeather.sunrise)")
                    DataWeather.sunset = weather.forecast.forecastday.first?.astro.sunset ?? ""
                    print("Время заката: \(DataWeather.sunset)")
                    DataWeather.windSpeed = weather.current.windKph
                    print("Скорость ветра: \(DataWeather.windSpeed)")

                    
                  } catch let jsonError{
                      print("Failed to decode", jsonError)
                      completion(nil, jsonError)
                  }
                    
              }
          }
        task.resume()
        
    }

    func createBackground(city: String, completion: @escaping (WelcomeImage?, Error?) -> Void) {
        print("Пошла func createBackground")
        let imageURL = "https://pixabay.com/api/?key=23370161-68858c4dc7a8da8189d451c8b&q=city_\(textF.text ?? "city")&image_type=video&pretty=true&orientation=vertical"
        
        print("\nСоздан URL: \(imageURL)")
          guard let stingURL = URL(string: imageURL) else {return}
          let task = URLSession.shared.dataTask(with: stingURL) { (data, response, error) in
            DispatchQueue.main.async {
              if let error = error {
                  completion(nil, error)
                  print("Хуевый URL")
                  return
              }
              guard let data = data else {return}
              do {
                  let image = try JSONDecoder().decode(WelcomeImage.self, from: data) // дата
                  completion(image, nil)
              } catch let jsonError{
                  print("Failed to decode", jsonError)
                  completion(nil, jsonError)
              }
          }
      }
        task.resume()
        
    }
    
    
    
    func creatingCollection() {
        let layout = UICollectionViewFlowLayout()
        collection = UICollectionView(frame: .zero,                                                            collectionViewLayout: layout)
        layout.collectionView?.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.0)
        guard let collection = collection else { return  }
        collection.register(UICollectionViewCell.self,                                               forCellWithReuseIdentifier:"cell")
        collection.dataSource = self
        collection.delegate = self
        collection.frame = CGRect(x: view.center.x - view.frame.width/4.5,
                                  y: view.center.y - 70,
                                  width: view.frame.width,
                                  height: 75)
        collection.alpha = 0.0
        view.addSubview(collection)
        
    }
    
    
    
   func createLabelCity(text: String, country: String) {
         nameOfCity.frame = CGRect(x: view.center.x - 135, y: view.center.y - 190, width: 270.0, height: 20.0)
         nameOfCity.text = "\(DataWeather.region)"
         nameOfCity.textColor = .white
         nameOfCity.textAlignment = .center
         nameOfCity.font.withSize(70)
         nameOfCity.alpha = 0.0

        nameOfCountry.frame = CGRect(x: view.center.x - 135, y: view.center.y - 175, width: 270.0, height: 30.0)
        nameOfCountry.text = "\(DataWeather.country)"
        nameOfCountry.textColor = .white
        nameOfCountry.textAlignment = .center
        nameOfCountry.font.withSize(70)
        nameOfCountry.alpha = 0.0
         self.view.addSubview(self.nameOfCountry)
         self.view.addSubview(self.nameOfCity)
         
         UIView.animate(withDuration: 2.5) {
            self.nameOfCountry.alpha = 1.0
            UIView.animate(withDuration: 5.0) {
                self.nameOfCity.alpha = 1.0
            }
         }
     }
    
    func tempOfLabel(temp: Int) {
        tempOfCity.font = UIFont.systemFont(ofSize: 140)
        tempOfCity.text = "\(Int(temp))°c"
        tempOfCity.textColor = .white
        tempOfCity.textAlignment = .center
        tempOfCity.alpha = 0.0
        tempOfCity.frame = CGRect(x: 0, y: self.view.center.y - 340.0, width: view.frame.width, height: 170)
        
        self.view.addSubview(self.tempOfCity)

      
        
        UIView.animate(withDuration: 1.5) {
            self.tempOfCity.alpha = 1.0
            self.celSign.alpha = 1.0
            UIView.animate(withDuration: 6.5) {
                self.tempOfCity.shadowColor = .black
                self.tempOfCity.shadowOffset = CGSize(width: 1.5, height: 1.5)
            }
            
        }
    }
    
    func createTextField() {
        
        searchIcon.frame = CGRect(x: view.center.x - 15 , y: view.center.y - 15, width: 30, height: 30)
        searchIcon.image = #imageLiteral(resourceName: "search")
        searchIcon.alpha = 1.0
        view.addSubview(searchIcon)
        
        textF.frame = CGRect(x: view.center.x - (( view.bounds.width - 100) / 2) , y: view.center.y - 35, width: view.bounds.width - 100, height: 70)
        textF.borderStyle = .roundedRect
        textF.placeholder = "Введите название города"
        textF.textAlignment = .center
        textF.textColor = .black
        textF.keyboardAppearance = .dark
        textF.clearButtonMode = .whileEditing
        self.view.center = textF.center
        view.addSubview(textF)
    }
    
    func gettingDesciption() {
        print("Start gettingDescription")
        weatherDescription.frame = CGRect(x: 0, y: self.view.center.y - 150.0, width: view.frame.width, height: 100)
        weatherDescription.font = UIFont.italicSystemFont(ofSize: 20)
        weatherDescription.text = "\(DataWeather.skyDescription)"
        weatherDescription.textColor = .white
        weatherDescription.textAlignment = .center
        weatherDescription.alpha = 0.0
        self.view.addSubview(self.weatherDescription)
        
        UIView.animate(withDuration: 6.5) {
            self.weatherDescription.alpha = 1.0
        }
    }
    
    
    

    
   
    
    //
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        UIView.animate(withDuration: 0.3) {
            textField.frame =  CGRect(x: self.view.center.x - (( self.view.bounds.width - 100) / 2) , y: self.view.center.y - 35, width: self.view.bounds.width - 100, height: 70)
            textField.alpha = 1.0
            self.collection?.alpha = 0.0
            
            self.searchIcon.frame = CGRect(x: self.view.center.x - 15 , y: self.view.center.y - 15, width: 30, height: 30)
            self.searchButt.alpha = 0.0
        }
        return true
    }
 
    
    func detailWeather() {
        
        sunriseLabel.image = #imageLiteral(resourceName: "sunrise")
        sunriseLabel.frame = CGRect(x: view.center.x - view.frame.width/2.5, y: view.center.y - 80, width: 50, height: 50)
        sunriseData.text = "\(DataWeather.sunrise)"
        sunriseData.frame = CGRect(x: view.center.x - view.frame.width/2.5 - sunriseLabel.frame.width/6, y: view.center.y - 80 + sunriseLabel.frame.height, width: 100, height: 50)
        sunriseData.textColor = .white
        
        
        windSpeedLabel.image = #imageLiteral(resourceName: "wind-signal")
        windSpeedLabel.frame = CGRect(x: view.center.x - sunriseLabel.frame.width/2, y: view.center.y - 80, width: 50, height: 50)
        windSpeedData.text = "\(DataWeather.windSpeed)"
        windSpeedData.frame = CGRect(x: view.center.x - sunriseLabel.frame.width/2, y: view.center.y - 80 + windSpeedLabel.frame.height, width: 100, height: 50)
        windSpeedData.textColor = .white
        
        
        sunsetLabel.image = #imageLiteral(resourceName: "sunset")
        sunsetLabel.frame = CGRect(x: view.center.x + view.frame.width/2.5 - sunriseLabel.frame.width, y: view.center.y - 80, width: 50, height: 50)
        sunsetData.text = "\(DataWeather.sunset)"
        sunsetData.frame = CGRect(x: view.center.x + view.frame.width/2.5 - sunriseLabel.frame.width - sunriseLabel.frame.width/6 , y: view.center.y - 80 + sunsetLabel.frame.height, width: 100, height: 50)
        sunsetData.textColor = .white
        
        view.addSubview(sunsetData)
        view.addSubview(sunsetLabel)
        
        view.addSubview(windSpeedData)
        view.addSubview(windSpeedLabel)
        
        view.addSubview(sunriseData)
        view.addSubview(sunriseLabel)
    }
    
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

            gettingData(city: textF.text!) { (weather, error) in
            //Получаем название города и страны
                self.createLabelCity(text: weather?.location.name ?? "Некорректный город", country: weather?.location.region ?? "Некорректный город")
            // Получаем температуру
                self.creatingCollection()
            //Создаем описание погоды
                self.gettingDesciption()
            
                
            //Анимация появления температуры
            UIView.animate(withDuration: 0.8) {
                if let  currentTemp = weather?.current.tempC {
                    self.tempOfLabel(temp: Int(currentTemp))
                }
            }
                
        }
     
        delay(bySeconds: 2.0) {
            print("Пауза")
            self.createBackground(city: self.textF.text!) { (image, error) in
                print("\nПошла createBackground")
                self.ImageURL = image?.hits.first?.largeImageURL ?? "Хуевый город"
                
                
                let url = URL(string: self.ImageURL)
                let data = try? Data(contentsOf: url ?? DataWeather.imageWithoutSky!)
                let imageView = UIImage(data: data!)
                imageView?.imageRendererFormat.preferredRange = .unspecified


                
             
                if self.view.backgroundColor != .black {
                    UIView.animate(withDuration: 3.0) {
                        self.view.backgroundColor?.withAlphaComponent(0.0)
                        print("\nАнимация1!")
                        self.view.backgroundColor = UIColor.black
                    } completion: { (Bool) in
                        UIView.animate(withDuration: 1.0) {
                                    print("\nАнимация3!")
                                    self.view.backgroundColor = UIColor(patternImage: ((imageView ?? self.safeImage.image)!))
                                }
                    }
                }
                
                if self.view.backgroundColor == UIColor.black {
                    UIView.animate(withDuration: 3.0) {
                        self.view.backgroundColor = UIColor(patternImage: ((imageView ?? self.safeImage.image)!))
                    }
                    UIView.animate(withDuration: 3.0) {
                        self.collection?.alpha = 1.0
                    }
                }

            }

            self.view.endEditing(true)
            self.textF.text = ""
            
            //Перемещение вниз поиска
            UIView.animate(withDuration: 0.7) { [self] in
                textField.backgroundColor?.withAlphaComponent(0.2)
                
                textField.frame = CGRect(x: view.center.x - 15 , y: self.view.center.y + 300, width: 45, height: 45)
                textField.alpha = 0.015
                searchIcon.frame = CGRect(x: self.view.center.x - 15, y: self.view.center.y + 300, width: 30, height: 30)
                self.searchButt.alpha = 1.0
                view.bringSubviewToFront(textField)
                

            }
            self.detailWeather()
        }
        //Получаем картинку на фон
        //Создаем CollectionView
        
      

        
        return true
    }


}
    
    
    
    
    
    
    


public func delay(bySeconds seconds: Double, dispatchLevel: DispatchLevel = .main, closure: @escaping () -> Void) {
    let dispatchTime = DispatchTime.now() + seconds
    dispatchLevel.dispatchQueue.asyncAfter(deadline: dispatchTime, execute: closure)
}

public enum DispatchLevel {
    case main, userInteractive, userInitiated, utility, background
    var dispatchQueue: DispatchQueue {
        switch self {
        case .main:                 return DispatchQueue.main
        case .userInteractive:      return DispatchQueue.global(qos: .userInteractive)
        case .userInitiated:        return DispatchQueue.global(qos: .userInitiated)
        case .utility:              return DispatchQueue.global(qos: .utility)
        case .background:           return DispatchQueue.global(qos: .background)
        }
    }
}

