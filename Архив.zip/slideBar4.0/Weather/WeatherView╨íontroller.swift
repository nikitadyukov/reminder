//
//  WeatherView.swift
//  slideBar4.0
//
//  Created by ПР on 22.09.2021.
//  Copyright © 2021 Никита Дюков. All rights reserved.
//

import Foundation



class WeatherViewController {
    
    var model = WeatherModel()
    
    
    func gettingData(queue: DispatchQueue ,priority: DispatchQoS,city: String, completion: @escaping (Welcome?, Error?)  -> Void) {
        print("Пошел func gettingData")
              let weatherURL = "http://api.weatherapi.com/v1/forecast.json?key=cead0fe85cfc4f5686d163725211909&q=\(city)&days=3&aqi=no&alerts=no"
              guard let stingURL = URL(string: weatherURL) else {return}
              let task = URLSession.shared.dataTask(with: stingURL) { (data, response, error) in
                DispatchQueue.main.sync {
                  if let error = error {
                      completion(nil, error)
                      print("Хуевый URL")
                      return
                  }
                  guard let data = data else {return}
                  do {
                    print("\nПолучил данные о городе...")
                      let weather = try JSONDecoder().decode(Welcome.self, from: data) // дата
                    
                    WeatherModel.DataWeather.sky = weather.current.condition.text.rawValue
                    print("Sky: \(WeatherModel.DataWeather.sky)")
                    WeatherModel.DataWeather.region = weather.location.region
                    print("Region: \(WeatherModel.DataWeather.region)")
                    WeatherModel.DataWeather.country = weather.location.country
                    print("Country: \(WeatherModel.DataWeather.country)")
                    WeatherModel.DataWeather.currentDayTemp = weather.current.tempC
                    print("Current temp:\(WeatherModel.DataWeather.currentDayTemp)")
                    WeatherModel.DataWeather.skyDescription = weather.current.condition.text.rawValue
                    print("Описание погоды: \(weather.current.condition.text.rawValue)")
                    WeatherModel.DataWeather.wind = weather.current.windKph
                    print("Скорость ветра: \(WeatherModel.DataWeather.wind)")
                      completion(weather, nil)
                    WeatherModel.DataWeather.sunrise = weather.forecast.forecastday.first?.astro.sunrise ?? ""
                    print("Время рассвета: \(WeatherModel.DataWeather.sunrise)")
                    WeatherModel.DataWeather.sunset = weather.forecast.forecastday.first?.astro.sunset ?? ""
                    print("Время заката: \(WeatherModel.DataWeather.sunset)")
                    WeatherModel.DataWeather.windSpeed = weather.current.windKph
                    print("Скорость ветра: \(WeatherModel.DataWeather.windSpeed)")
                  } catch let jsonError{
                      print("Failed to decode", jsonError)
                      completion(nil, jsonError)
                  }
              }
          }
        print("End func gettingData")
        task.resume()
    }
    
    
}
